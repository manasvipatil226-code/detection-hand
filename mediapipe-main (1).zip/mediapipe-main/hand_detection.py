import cv2
import mediapipe as mp


#initialize mediapipe hands module
mp_hands=mp.solutions.hands  #load the mediapipe hands module
hands=mp_hands.Hands()  # create the hand detector object

#Draw the utlity for drawing the hand landmarks
mp_drawing=mp.solutions.drawing_utils #draw the red dots and green lines on the hand landmarks


cap= cv2.VideoCapture(0) #open default camera

while True:
    
    ret,frame = cap.read()

    if not ret:
        break

    #convert BGR to RGB
    
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    #process the frame and detect the hands
  
    result=hands.process(rgb_frame)

    if result.multi_hand_landmarks:

        for i in result.multi_hand_landmarks:

            mp_drawing.draw_landmarks(frame,i,mp_hands.HAND_CONNECTIONS) #draw the hand landmarks on the frame



    cv2.imshow('Hand Detection', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()



